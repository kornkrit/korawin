-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 22, 2016 at 09:11 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `db_korawin`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `board`
-- 

CREATE TABLE `board` (
  `id` int(5) unsigned zerofill NOT NULL auto_increment,
  `title` text NOT NULL,
  `detail` text NOT NULL,
  `date` date NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` text NOT NULL,
  `view` int(11) NOT NULL,
  `reply` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

-- 
-- Dumping data for table `board`
-- 

INSERT INTO `board` VALUES (00013, 'Kornkrit', 'test na kub', '2013-06-20', '', '', 0, 0);
INSERT INTO `board` VALUES (00014, 'this is a test', 'à¸ªà¸§à¸±à¸ªà¸”à¸µà¸„à¸£à¸±à¸šà¸žà¸µà¹ˆà¸™à¹‰à¸­à¸‡à¸Šà¸²à¸§à¸§à¹„à¸—à¸¢', '2013-06-21', '', 'kornkrit.s@hotmail.com', 7, 5);
INSERT INTO `board` VALUES (00012, 'Welcome To korawin.com webboard', 'à¸ªà¸§à¸±à¸ªà¸”à¸µà¸„à¸£à¸±à¸šà¸žà¹ˆà¸­à¹à¸¡à¹ˆà¸žà¸µà¹ˆà¸™à¹‰à¸­à¸‡à¸Šà¸²à¸§à¹„à¸—à¸¢', '2013-06-20', '', 'kornkrit.s@hotmail.com', 16, 4);
INSERT INTO `board` VALUES (00015, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 4, 5);
INSERT INTO `board` VALUES (00016, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 2, 3);
INSERT INTO `board` VALUES (00017, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00018, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00019, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 2, 3);
INSERT INTO `board` VALUES (00020, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00021, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00022, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00023, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00024, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00025, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00026, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00027, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00028, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00029, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00030, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00031, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00032, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00033, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00034, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00035, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00036, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 1, 3);
INSERT INTO `board` VALUES (00037, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 2, 3);
INSERT INTO `board` VALUES (00038, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 7, 3);
INSERT INTO `board` VALUES (00039, 'fds', 'sdaf', '2013-06-11', 'sdafs', 'sdafsdf', 2, 3);
INSERT INTO `board` VALUES (00040, 'à¸”à¸à¸«', 'à¸”à¸à¸«à¸Ÿ', '2013-06-22', '', 'kornkrit.s@hotmail.com', 14, 4);
INSERT INTO `board` VALUES (00041, 'This is a test?', 'à¸à¹‡à¹à¸„à¹ˆà¸­à¸¢à¸²à¸à¸£à¸¹à¹‰à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹ƒà¸Šà¹‰à¹„à¸”à¹‰à¸«à¸£à¸·à¸­à¹€à¸›à¸¥à¹ˆà¸² à¸šà¸­à¸à¸«à¸™à¹ˆà¸­à¸¢à¹„à¸”à¹‰à¹„à¸«à¸¡', '2013-06-22', '', 'kornkrit.s@hotmail.com', 66, 10);
INSERT INTO `board` VALUES (00042, 'à¸­à¸¢à¸²à¸à¸£à¸¹à¹‰à¸™à¸µà¹ˆà¹€à¸¥à¸™à¸ªà¹Œà¸­à¸°à¹„à¸£à¸„à¸£à¸±à¸š', '<IMG>http://f.ptcdn.info/461/006/000/1371885153-feef815lu5-o.gif</IMG>', '2013-06-22', '', 'kornkrit.s@hotmail.com', 64, 10);

-- --------------------------------------------------------

-- 
-- Table structure for table `forum`
-- 

CREATE TABLE `forum` (
  `forum_id` int(5) unsigned zerofill NOT NULL auto_increment,
  `forum_name` text NOT NULL,
  `forum_info` text NOT NULL,
  PRIMARY KEY  (`forum_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `forum`
-- 

INSERT INTO `forum` VALUES (00006, 'Trip Agigu', 'This is a test');
INSERT INTO `forum` VALUES (00005, 'Trip 1', 'เกี่ยวกับการเกษตร');

-- --------------------------------------------------------

-- 
-- Table structure for table `forum_sub`
-- 

CREATE TABLE `forum_sub` (
  `forum_sub_id` int(5) unsigned zerofill NOT NULL auto_increment,
  `forum_id` int(5) unsigned zerofill NOT NULL,
  `forum_sub_name` text NOT NULL,
  `forum_sub_info` text NOT NULL,
  `forum_sub_post` int(11) NOT NULL,
  PRIMARY KEY  (`forum_sub_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `forum_sub`
-- 

INSERT INTO `forum_sub` VALUES (00005, 00006, 'test 2', '', 0);
INSERT INTO `forum_sub` VALUES (00004, 00005, 'Test 1', 'เกี่ยวกับการทดสอบ1', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `member`
-- 

CREATE TABLE `member` (
  `id` int(8) unsigned zerofill NOT NULL auto_increment,
  `name` text NOT NULL,
  `surname` text NOT NULL,
  `user` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `member`
-- 

INSERT INTO `member` VALUES (00000001, 'Kornkrit', 'Supayanant', 'kornkrit.s', '08102535', 'kornkrit.s@hotmail.com', '0894514236');
INSERT INTO `member` VALUES (00000002, 'Vasu', 'Supayanant', 'vasu_sup', 'vs1120', 'vasu_sup@yahoo.com', '0863673863');
INSERT INTO `member` VALUES (00000003, 'Srisuwan', 'Supayanant', 'srisuwan', 'd36u84bg', 'srisuwan@hotmail.com', '086-367-3863');
INSERT INTO `member` VALUES (00000004, 'kornkrit', 'supayanant', 'kornkrit.sup', 'k08102535', 'kornkrit.sup@student.mahidol.ac.th', '089-451-4236');
INSERT INTO `member` VALUES (00000005, 'Laddawan', 'Sae-Lee', 'onedayni', 'l131235', 'oneday@hotmail.com', '087-320-8447');

-- --------------------------------------------------------

-- 
-- Table structure for table `reply`
-- 

CREATE TABLE `reply` (
  `ReplyID` int(5) unsigned zerofill NOT NULL auto_increment,
  `QuestionID` int(5) unsigned zerofill NOT NULL,
  `CreateDate` datetime NOT NULL,
  `Details` text NOT NULL,
  `Name` varchar(50) NOT NULL,
  PRIMARY KEY  (`ReplyID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

-- 
-- Dumping data for table `reply`
-- 

INSERT INTO `reply` VALUES (00001, 00016, '2012-03-22 16:13:18', 'Please visit www.thaicreate.com', 'plakrim');
INSERT INTO `reply` VALUES (00002, 00016, '2012-03-22 16:14:56', 'Thanks. www.thaicreate.com is great web for the php and mysql.', 'mr.win');
INSERT INTO `reply` VALUES (00003, 00016, '2013-06-21 12:54:26', 'fdsfs', 'fsd');
INSERT INTO `reply` VALUES (00004, 00013, '2013-06-21 13:03:08', 'sdfasdf', 'sdf');
INSERT INTO `reply` VALUES (00005, 00041, '2013-06-22 11:13:36', '´¡Ë´', 'Ë¡´');
INSERT INTO `reply` VALUES (00006, 00041, '2013-06-22 11:13:40', '´¡Ë´', 'Ë¡´');
INSERT INTO `reply` VALUES (00007, 00041, '2013-06-22 11:13:45', '´¡Ë´', 'Ë¡´');
INSERT INTO `reply` VALUES (00008, 00041, '2013-06-22 11:15:19', '´¡Ë´', 'Ë¡´');
INSERT INTO `reply` VALUES (00009, 00041, '2013-06-22 11:15:22', '´¡Ë´', 'Ë¡´');
INSERT INTO `reply` VALUES (00010, 00041, '2013-06-22 11:15:33', 'àË´à¡´à', '´¡´');
INSERT INTO `reply` VALUES (00011, 00041, '2013-06-22 11:15:43', 'àË´à¡´à', '´¡´');
INSERT INTO `reply` VALUES (00012, 00041, '2013-06-22 11:17:18', 'àË´à¡´à', '´¡´');
INSERT INTO `reply` VALUES (00013, 00041, '2013-06-22 11:17:21', 'àË´à¡´à', '´¡´');
INSERT INTO `reply` VALUES (00014, 00041, '2013-06-22 13:36:30', 'sdf', 'sdf');
INSERT INTO `reply` VALUES (00015, 00041, '2013-06-22 13:36:37', 'kornkrit', 'kornkrit');
INSERT INTO `reply` VALUES (00016, 00041, '2013-06-22 13:37:02', 'fds', 'fds');
INSERT INTO `reply` VALUES (00017, 00041, '2013-06-22 13:37:05', 'fds', 'fds');
INSERT INTO `reply` VALUES (00018, 00041, '2013-06-22 13:37:35', 'kornkrit', 'gear');
INSERT INTO `reply` VALUES (00019, 00040, '2013-06-22 13:37:43', 'fds', 'fds');
INSERT INTO `reply` VALUES (00020, 00040, '2013-06-22 13:37:49', 'fdsf', 'fd');
INSERT INTO `reply` VALUES (00021, 00015, '2013-06-22 13:38:41', 'sadf', 'asdf');
INSERT INTO `reply` VALUES (00022, 00015, '2013-06-22 13:38:44', 'sdfsdf', 'fdsfd');
INSERT INTO `reply` VALUES (00023, 00040, '2013-06-22 14:29:27', 'fdsf', 'fd');
INSERT INTO `reply` VALUES (00024, 00040, '2013-06-22 14:32:20', 'fdsf', 'fd');
INSERT INTO `reply` VALUES (00025, 00012, '2013-06-22 14:39:36', 'Test', 'fd');
INSERT INTO `reply` VALUES (00026, 00041, '2013-06-22 15:29:23', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¸ˆà¸°à¹„à¸¡à¹ˆà¹€à¸«à¸¡à¸²à¸ªà¸¡à¸™à¸°à¸„à¸£à¸±à¸š\r\n', '');
INSERT INTO `reply` VALUES (00027, 00041, '2013-06-22 15:34:15', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¸ˆà¸°à¹„à¸¡à¹ˆà¹€à¸«à¸¡à¸²à¸ªà¸¡à¸™à¸°à¸„à¸£à¸±à¸š\r\n', 'Kornkrit');
INSERT INTO `reply` VALUES (00028, 00041, '2013-06-22 15:34:28', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00029, 00041, '2013-06-22 15:36:08', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00030, 00041, '2013-06-22 15:37:19', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00031, 00041, '2013-06-22 15:37:43', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00032, 00041, '2013-06-22 15:38:25', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00033, 00041, '2013-06-22 15:38:45', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00034, 00041, '2013-06-22 15:39:03', 'à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸¡à¸±à¸™à¹€à¸«à¸¡à¸²à¸°à¸ªà¸¡à¹à¸¥à¹‰à¸§à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00035, 00012, '2013-06-22 15:39:43', 'à¹„à¸”à¹‰à¹† à¹€à¸”à¸µà¹ˆà¸¢à¸§à¹€à¸ˆà¸­à¸à¸±à¸™à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00036, 00012, '2013-06-22 16:05:45', 'à¹„à¸”à¹‰à¹† à¹€à¸”à¸µà¹ˆà¸¢à¸§à¹€à¸ˆà¸­à¸à¸±à¸™à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00037, 00012, '2013-06-22 16:05:58', 'à¹„à¸”à¹‰à¹† à¹€à¸”à¸µà¹ˆà¸¢à¸§à¹€à¸ˆà¸­à¸à¸±à¸™à¸™à¸°à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00038, 00042, '2013-06-22 16:20:43', '<img>http://f.ptcdn.info/461/006/000/1371885153-feef815lu5-o.gif</img>', 'Kornkrit');
INSERT INTO `reply` VALUES (00039, 00042, '2013-06-22 16:21:09', '<img http://stonemetalfire.com/webboard/files/thumbs/t_smf_gold_logo_110.jpg>', 'Kornkrit');
INSERT INTO `reply` VALUES (00040, 00042, '2013-06-22 16:21:30', '<img src="http://stonemetalfire.com/webboard/files/thumbs/t_smf_gold_logo_110.jpg" />', 'Kornkrit');
INSERT INTO `reply` VALUES (00041, 00042, '2013-06-22 18:07:50', 'http://www.youtube.com/watch?v=D8iRG-lojfI&list=RD02UBaUxoizsuY', 'Kornkrit');
INSERT INTO `reply` VALUES (00042, 00042, '2013-06-22 18:08:10', '<video src = "http://www.youtube.com/watch?v=D8iRG-lojfI&list=RD02UBaUxoizsuY">', 'Kornkrit');
INSERT INTO `reply` VALUES (00043, 00042, '2013-06-22 18:08:40', '[youtube]http://www.youtube.com/watch?v=D8iRG-lojfI&list=RD02UBaUxoizsuY[/youtube]', 'Kornkrit');
INSERT INTO `reply` VALUES (00044, 00042, '2013-06-22 18:09:00', '<video src "http://www.youtube.com/watch?v=D8iRG-lojfI&list=RD02UBaUxoizsuY" />', 'Kornkrit');
INSERT INTO `reply` VALUES (00045, 00042, '2013-06-22 18:10:23', '<video src = "http://www.youtube.com/watch?v=7BRw44TojXs" />', 'Kornkrit');
INSERT INTO `reply` VALUES (00046, 00042, '2013-06-22 22:44:43', 'à¹à¸«à¸°à¹† à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸«à¸™à¸±à¸‡à¹€à¸£à¸·à¹ˆà¸­à¸‡à¸™à¸µà¹‰à¸¡à¸±à¸™à¸ªà¸™à¸¸à¸à¸¡à¸²à¸à¹€à¸£à¸¢à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00047, 00042, '2013-06-22 22:45:17', 'à¹à¸«à¸°à¹† à¸œà¸¡à¸„à¸´à¸”à¸§à¹ˆà¸²à¸«à¸™à¸±à¸‡à¹€à¸£à¸·à¹ˆà¸­à¸‡à¸™à¸µà¹‰à¸¡à¸±à¸™à¸ªà¸™à¸¸à¸à¸¡à¸²à¸à¹€à¸£à¸¢à¸„à¸£à¸±à¸š', 'Kornkrit');
INSERT INTO `reply` VALUES (00048, 00014, '2013-06-23 16:30:20', 'fd', 'fd');
INSERT INTO `reply` VALUES (00049, 00014, '2013-06-23 16:30:22', 'fd', 'fd');
INSERT INTO `reply` VALUES (00050, 00014, '2013-06-23 16:30:29', 'fd', 'fd');
INSERT INTO `reply` VALUES (00051, 00014, '2013-06-23 16:30:34', 'dfgh', 'dfghn');
INSERT INTO `reply` VALUES (00052, 00014, '2013-06-23 16:33:18', 'dfgh', 'dfghn');

-- --------------------------------------------------------

-- 
-- Table structure for table `test`
-- 

CREATE TABLE `test` (
  `id` varchar(50) NOT NULL,
  `name` int(11) NOT NULL,
  PRIMARY KEY  (`id`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `test`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `test2`
-- 

CREATE TABLE `test2` (
  `id` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `test2`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `webboard`
-- 

CREATE TABLE `webboard` (
  `QuestionID` int(5) unsigned zerofill NOT NULL auto_increment,
  `CreateDate` datetime NOT NULL,
  `Question` varchar(255) NOT NULL,
  `Details` text NOT NULL,
  `Name` varchar(50) NOT NULL,
  `View` int(5) NOT NULL,
  `Reply` int(5) NOT NULL,
  PRIMARY KEY  (`QuestionID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `webboard`
-- 

INSERT INTO `webboard` VALUES (00001, '2012-03-22 15:37:54', 'Help me here. I love it. But out of this.', 'Detail for : Help me here. I love it. But out of this.', 'cook chicken', 4, 1);
INSERT INTO `webboard` VALUES (00002, '2012-03-22 15:37:54', 'Why compare the data in the sql language. But if the numbers.	', 'Detail for : Why compare the data in the sql language. But if the numbers.	', 'koo_service', 0, 0);
INSERT INTO `webboard` VALUES (00003, '2012-03-22 15:37:54', 'The values ??in the Text box to use when removed from the List Box.', 'Detail for : The values ??in the Text box to use when removed from the List Box.	', 'Bee.', 0, 0);
INSERT INTO `webboard` VALUES (00004, '2012-03-22 15:37:54', 'Ask me how I have used it to my PHPExcel.', 'Detail for : Ask me how I have used it to my PHPExcel.	', 'PlaKriM.	', 0, 0);
INSERT INTO `webboard` VALUES (00005, '2012-03-22 15:37:54', 'You know me ... textbox code number is entered at the stem and then a textbox to another textbox and press tab to another.', 'Detail for : You know me ... textbox code number is entered at the stem and then a textbox to another textbox and press tab to another.	', 'mr.win', 0, 0);
INSERT INTO `webboard` VALUES (00006, '2012-03-22 15:37:54', 'How to convert date from year to year, then evaluate the current age.	', 'Detail for : How to convert date from year to year, then evaluate the current age.	', 'Jae', 0, 0);
INSERT INTO `webboard` VALUES (00007, '2012-03-22 15:37:54', 'I do asp.net but I have a question about my file. Why does the archive folder. Existing file, a single thread.', 'Detail for : I do asp.net but I have a question about my file. Why does the archive folder. Existing file, a single thread.	', 'pat.', 0, 0);
INSERT INTO `webboard` VALUES (00008, '2012-03-22 15:37:54', 'Thanks for the advice. I write code to search from the main square with the sell_id', 'Detail for : Thanks for the advice. I write code to search from the main square with the sell_id', 'sodong.', 0, 0);
INSERT INTO `webboard` VALUES (00009, '2012-03-22 15:37:54', 'I ask my friends. The wrapping. I want to separate words	', 'Detail for : I ask my friends. The wrapping. I want to separate words', 'noy', 0, 0);
INSERT INTO `webboard` VALUES (00010, '2012-03-22 15:37:54', 'I used to. Focus () the cursor to the last scene of the text in the textbox	', 'Detail for : I used to. Focus () the cursor to the last scene of the text in the textbox	', 'oasiis', 0, 0);
INSERT INTO `webboard` VALUES (00011, '2012-03-22 15:37:54', 'Help write the story to me in my OOP database postgresql	', 'Detail for : Help write the story to me in my OOP database postgresql	', 'minutes', 0, 0);
INSERT INTO `webboard` VALUES (00012, '2012-03-22 15:37:54', 'Config file that loads the message id, message value to a system call to load the config of this post.	', 'Detail for : Config file that loads the message id, message value to a system call to load the config of this post.	', 'ago', 0, 0);
INSERT INTO `webboard` VALUES (00013, '2012-03-22 15:37:54', 'Hope to see the Code during my search. Asp	', 'Detail for : Hope to see the Code during my search. Asp	', 'A', 3, 1);
INSERT INTO `webboard` VALUES (00014, '2012-03-22 15:37:54', 'The value in the textbox value from db where the textbox is in the dropdown to change the value from the db as well	', 'Detail for : The value in the textbox value from db where the textbox is in the dropdown to change the value from the db as well	', 'jum', 1, 0);
INSERT INTO `webboard` VALUES (00015, '2012-03-22 15:37:54', 'jquery ui datepicker calendar. Assistance in the form of redundancy	', 'Detail for : jquery ui datepicker calendar. Assistance in the form of redundancy	', 'Prairie', 0, 0);
INSERT INTO `webboard` VALUES (00016, '2012-03-22 16:12:24', 'How to use php and mysql database', 'Dear all,\r\nI am need to connect php to mysql database please suggest source code to tutorial.', 'mr.win', 7, 3);
